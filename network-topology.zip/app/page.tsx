import NetworkTopologyVisualizer from "@/components/network-topology-visualizer"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex h-screen w-full">
        <NetworkTopologyVisualizer />
      </div>
    </main>
  )
}
