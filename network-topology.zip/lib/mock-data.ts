import type { Node, Edge } from "reactflow"

// Generate random number within range
const randomInRange = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Generate random float within range with precision
const randomFloatInRange = (min: number, max: number, precision = 2) => {
  const value = Math.random() * (max - min) + min
  return Number.parseFloat(value.toFixed(precision))
}

// Generate random health status with weighted probability
const randomHealthStatus = () => {
  const rand = Math.random()
  if (rand > 0.9) return "down"
  if (rand > 0.7) return "degraded"
  return "up"
}

// Generate mock topology data
export const generateMockTopology = () => {
  const initialNodes: Node[] = []
  const initialEdges: Edge[] = []

  // Configuration
  const podCount = 4
  const fabricCount = 3
  const borderDevicesPerFabric = 4
  const spinesPerFabric = 6 // Total spines per fabric, not per border
  const cabinetsPerFabric = 6
  const leavesPerCabinet = 3

  // Vertical spacing - each level has its own row
  const podY = 50
  const fabricY = 150
  const borderY = 250
  const spineY = 350
  const cabinetY = 450
  const leafY = 550

  // Horizontal spacing multipliers
  const podSpacing = 250
  const fabricSpacing = 700
  const borderSpacing = 150
  const spineSpacing = 120
  const cabinetSpacing = 200
  const leafSpacing = 80

  // Create Pods (top row)
  for (let i = 1; i <= podCount; i++) {
    initialNodes.push({
      id: `pod-${i}`,
      type: "pod",
      position: { x: i * podSpacing, y: podY },
      data: {
        label: `Pod ${i}`,
        role: "Entry Aggregation",
        isExpanded: false,
        level: "pod",
      },
    })
  }

  // Create Fabrics
  for (let i = 1; i <= fabricCount; i++) {
    const fabricId = `fabric-${i}`
    const fabricX = i * fabricSpacing

    initialNodes.push({
      id: fabricId,
      type: "fabric",
      position: { x: fabricX, y: fabricY },
      data: {
        label: `Fabric ${i}`,
        borderCount: borderDevicesPerFabric,
        spineCount: spinesPerFabric,
        cabinetCount: cabinetsPerFabric,
        isExpanded: false,
        level: "fabric",
      },
      hidden: true, // Hidden by default until pod is expanded
    })

    // Connect Pods to Fabrics
    for (let p = 1; p <= podCount; p++) {
      const health = randomHealthStatus()
      const capacity = 100 // 100G
      const utilization = randomInRange(10, 90)
      const bandwidth = (capacity * utilization) / 100

      initialEdges.push({
        id: `edge-pod${p}-fabric${i}`,
        source: `pod-${p}`,
        target: fabricId,
        type: "status",
        hidden: true, // Hidden by default until pod is expanded
        data: {
          sourceDevice: `Pod ${p}`,
          targetDevice: `Fabric ${i}`,
          sourceInterface: `eth1/${i}`,
          targetInterface: `eth1/${p}`,
          type: "pod-to-fabric",
          speed: "100G",
          capacity,
          bandwidth,
          utilization,
          packetErrorRate: randomFloatInRange(0, 0.2, 3),
          latency: randomFloatInRange(0.5, 5, 1),
          health,
          lastUpdated: new Date().toISOString(),
          level: "pod-to-fabric",
        },
      })
    }

    // Create Border Devices for each Fabric
    for (let j = 1; j <= borderDevicesPerFabric; j++) {
      const borderId = `border-${i}-${j}`
      const borderX = fabricX - (borderDevicesPerFabric * borderSpacing) / 2 + j * borderSpacing

      initialNodes.push({
        id: borderId,
        type: "border",
        position: { x: borderX, y: borderY },
        data: {
          label: `Border ${i}-${j}`,
          role: "Fabric Border Device",
          parentFabric: fabricId,
          isExpanded: false,
          level: "border",
        },
        hidden: true, // Hidden by default until fabric is expanded
      })
    }

    // Create Spines for each Fabric (not per border)
    for (let s = 1; s <= spinesPerFabric; s++) {
      const spineId = `spine-${i}-${s}`
      // Position spines in a row
      const spineX = fabricX - (spinesPerFabric * spineSpacing) / 2 + s * spineSpacing

      initialNodes.push({
        id: spineId,
        type: "spine",
        position: { x: spineX, y: spineY },
        data: {
          label: `Spine ${i}-${s}`,
          role: "Spine Switch",
          parentFabric: fabricId,
          isExpanded: false,
          level: "spine",
        },
        hidden: true, // Hidden by default until border is expanded
      })

      // Connect all Border Devices to all Spines in the same fabric
      for (let j = 1; j <= borderDevicesPerFabric; j++) {
        const borderId = `border-${i}-${j}`
        const health = randomHealthStatus()
        const capacity = 100 // 100G
        const utilization = randomInRange(10, 90)
        const bandwidth = (capacity * utilization) / 100

        initialEdges.push({
          id: `edge-border${i}-${j}-spine${i}-${s}`,
          source: borderId,
          target: spineId,
          type: "status",
          hidden: true, // Hidden by default until border is expanded
          data: {
            sourceDevice: `Border ${i}-${j}`,
            targetDevice: `Spine ${i}-${s}`,
            sourceInterface: `eth2/${s}`,
            targetInterface: `eth1/${j}`,
            type: "border-to-spine",
            speed: "100G",
            capacity,
            bandwidth,
            utilization,
            packetErrorRate: randomFloatInRange(0, 0.2, 3),
            latency: randomFloatInRange(0.5, 5, 1),
            health,
            lastUpdated: new Date().toISOString(),
            parentFabric: fabricId,
            level: "border-to-spine",
          },
        })
      }
    }

    // Create Cabinets for each Fabric
    for (let j = 1; j <= cabinetsPerFabric; j++) {
      const cabinetId = `cabinet-${i}-${j}`
      // Position cabinets in a row
      const cabinetX = fabricX - (cabinetsPerFabric * cabinetSpacing) / 2 + j * cabinetSpacing

      initialNodes.push({
        id: cabinetId,
        type: "cabinet",
        position: { x: cabinetX, y: cabinetY },
        data: {
          label: `Cabinet ${i}-${j}`,
          leafCount: leavesPerCabinet,
          parentFabric: fabricId,
          isExpanded: false,
          level: "cabinet",
        },
        hidden: true, // Hidden by default until fabric is expanded
      })

      // Create Leaves inside each Cabinet
      for (let k = 1; k <= leavesPerCabinet; k++) {
        const leafId = `leaf-${i}-${j}-${k}`
        const leafX = cabinetX - (leavesPerCabinet * leafSpacing) / 2 + k * leafSpacing

        initialNodes.push({
          id: leafId,
          type: "leaf",
          position: { x: leafX, y: leafY },
          data: {
            label: `Leaf ${i}-${j}-${k}`,
            ports: 48,
            parentFabric: fabricId,
            parentCabinet: cabinetId,
            level: "leaf",
          },
          hidden: true, // Hidden by default until cabinet is expanded
        })

        // Connect all Spines to all Leaves in the same fabric
        for (let s = 1; s <= spinesPerFabric; s++) {
          const spineId = `spine-${i}-${s}`
          const health = randomHealthStatus()
          const capacity = 40 // 40G
          const utilization = randomInRange(5, 80)
          const bandwidth = (capacity * utilization) / 100

          initialEdges.push({
            id: `edge-spine${i}-${s}-leaf${i}-${j}-${k}`,
            source: spineId,
            target: leafId,
            type: "status",
            hidden: true, // Hidden by default
            data: {
              sourceDevice: `Spine ${i}-${s}`,
              targetDevice: `Leaf ${i}-${j}-${k}`,
              sourceInterface: `eth2/${j * leavesPerCabinet + k}`,
              targetInterface: `eth1/${s}`,
              type: "spine-to-leaf",
              speed: "40G",
              capacity,
              bandwidth,
              utilization,
              packetErrorRate: randomFloatInRange(0, 0.2, 3),
              latency: randomFloatInRange(0.5, 5, 1),
              health,
              lastUpdated: new Date().toISOString(),
              parentFabric: fabricId,
              parentSpine: spineId,
              level: "spine-to-leaf",
            },
          })
        }
      }
    }
  }

  return { initialNodes, initialEdges }
}
