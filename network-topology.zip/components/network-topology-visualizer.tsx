"use client"

import type React from "react"

import { useState, useCallback, useEffect } from "react"
import ReactFlow, {
  type Node,
  type Edge,
  Controls,
  Background,
  MiniMap,
  Panel,
  useNodesState,
  useEdgesState,
  type NodeTypes,
  type EdgeTypes,
  useReactFlow,
  ReactFlowProvider,
} from "reactflow"
import "reactflow/dist/style.css"

import { generateMockTopology } from "@/lib/mock-data"
import { PodNode } from "./custom-nodes/pod-node"
import { FabricNode } from "./custom-nodes/fabric-node"
import { BorderNode } from "./custom-nodes/border-node"
import { SpineNode } from "./custom-nodes/spine-node"
import { CabinetNode } from "./custom-nodes/cabinet-node"
import { LeafNode } from "./custom-nodes/leaf-node"
import { StatusEdge } from "./custom-edges/status-edge"
import EdgeDetailsPanel from "./edge-details-panel"
import DeviceDetailsPanel from "./device-details-panel"
import TopologyControls from "./topology-controls"

const nodeTypes: NodeTypes = {
  pod: PodNode,
  fabric: FabricNode,
  border: BorderNode,
  spine: SpineNode,
  cabinet: CabinetNode,
  leaf: LeafNode,
}

const edgeTypes: EdgeTypes = {
  status: StatusEdge,
}

// Hierarchy levels in order
const hierarchyLevels = ["pod", "fabric", "border", "spine", "cabinet", "leaf"]

function NetworkTopologyVisualizerContent() {
  const reactFlowInstance = useReactFlow()
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null)
  const [selectedDevice, setSelectedDevice] = useState<{ id: string; type: string } | null>(null)
  const [healthFilter, setHealthFilter] = useState<string>("all")
  const [searchTerm, setSearchTerm] = useState<string>("")
  const [initialNodePositions, setInitialNodePositions] = useState<Record<string, { x: number; y: number }>>({})

  // Initialize with mock data
  useEffect(() => {
    const { initialNodes, initialEdges } = generateMockTopology()

    // Add handlers to all nodes
    const nodesWithHandlers = initialNodes.map((node) => {
      return {
        ...node,
        data: {
          ...node.data,
          onExpandAll: node.type === "fabric" ? (fabricId: string) => expandAllInFabric(fabricId) : undefined,
          onCollapseAll: node.type === "fabric" ? (fabricId: string) => collapseAllInFabric(fabricId) : undefined,
          onShowDetails: (nodeId: string, nodeType: string) => showDeviceDetails(nodeId, nodeType),
        },
      }
    })

    // Save initial positions for reset functionality
    const positions: Record<string, { x: number; y: number }> = {}
    initialNodes.forEach((node) => {
      positions[node.id] = { x: node.position.x, y: node.position.y }
    })
    setInitialNodePositions(positions)

    setNodes(nodesWithHandlers)
    setEdges(initialEdges)
  }, [setNodes, setEdges])

  // Handle edge click to show details
  const onEdgeClick = useCallback(
    (event: React.MouseEvent, edge: Edge) => {
      setSelectedEdge(edge)
      setSelectedDevice(null) // Close device panel if open
    },
    [setSelectedEdge],
  )

  // Function to show device details
  const showDeviceDetails = useCallback((nodeId: string, nodeType: string) => {
    setSelectedDevice({ id: nodeId, type: nodeType })
    setSelectedEdge(null) // Close edge panel if open
  }, [])

  // Function to get all levels below a given level
  const getLevelsBelow = useCallback((level: string) => {
    const levelIndex = hierarchyLevels.indexOf(level)
    return hierarchyLevels.slice(levelIndex + 1)
  }, [])

  // Function to check if all nodes of a specific type in a fabric are collapsed
  const areAllNodesOfTypeCollapsed = useCallback(
    (nodeType: string, fabricId: string) => {
      const nodesOfType = nodes.filter(
        (n) => n.data.level === nodeType && n.data.parentFabric === fabricId && !n.hidden,
      )
      return nodesOfType.every((n) => !n.data.isExpanded)
    },
    [nodes],
  )

  // Function to check if all pods are collapsed
  const areAllPodsCollapsed = useCallback(() => {
    const pods = nodes.filter((n) => n.data.level === "pod" && !n.hidden)
    return pods.every((n) => !n.data.isExpanded)
  }, [nodes])

  // Function to check if a node has connections from other nodes of the same type
  const hasConnectionsFromOtherNodes = useCallback(
    (nodeId: string, nodeType: string, fabricId?: string) => {
      // Get all nodes of the same type
      const sameTypeNodes = nodes.filter(
        (n) => n.data.level === nodeType && n.id !== nodeId && !n.hidden && n.data.isExpanded,
      )

      // For each node of the same type, check if it has connections to children of the current node
      for (const otherNode of sameTypeNodes) {
        // Get connections from this other node
        const connectionsFromOtherNode = edges.filter((e) => e.source === otherNode.id && !e.hidden)

        // If there are any connections, return true
        if (connectionsFromOtherNode.length > 0) {
          return true
        }
      }

      return false
    },
    [nodes, edges],
  )

  // Function to hide connections from a node
  const hideConnectionsFromNode = useCallback(
    (nodeId: string) => {
      setEdges((eds) =>
        eds.map((e) => {
          if (e.source === nodeId) {
            return {
              ...e,
              hidden: true,
            }
          }
          return e
        }),
      )
    },
    [setEdges],
  )

  // Function to hide nodes of specific levels in a fabric
  const hideNodesOfLevelsInFabric = useCallback(
    (levels: string[], fabricId: string) => {
      setNodes((nds) =>
        nds.map((n) => {
          if (levels.includes(n.data.level) && n.data.parentFabric === fabricId) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: false,
              },
              hidden: true,
            }
          }
          return n
        }),
      )
    },
    [setNodes],
  )

  // Function to hide all nodes in a fabric
  const hideAllNodesInFabric = useCallback(
    (fabricId: string) => {
      const levelsToHide = getLevelsBelow("fabric")
      hideNodesOfLevelsInFabric(levelsToHide, fabricId)
    },
    [getLevelsBelow, hideNodesOfLevelsInFabric],
  )

  // Function to hide edges between specific levels in a fabric
  const hideEdgesBetweenLevelsInFabric = useCallback(
    (levels: string[], fabricId: string) => {
      setEdges((eds) =>
        eds.map((e) => {
          const sourceNode = nodes.find((n) => n.id === e.source)
          const targetNode = nodes.find((n) => n.id === e.target)

          if (
            sourceNode &&
            targetNode &&
            sourceNode.data.parentFabric === fabricId &&
            (levels.includes(sourceNode.data.level) || levels.includes(targetNode.data.level))
          ) {
            return {
              ...e,
              hidden: true,
            }
          }
          return e
        }),
      )
    },
    [setEdges, nodes],
  )

  // Function to hide all edges in a fabric
  const hideAllEdgesInFabric = useCallback(
    (fabricId: string) => {
      setEdges((eds) =>
        eds.map((e) => {
          const sourceNode = nodes.find((n) => n.id === e.source)
          const targetNode = nodes.find((n) => n.id === e.target)

          if (
            (sourceNode && sourceNode.data.parentFabric === fabricId) ||
            (targetNode && targetNode.data.parentFabric === fabricId)
          ) {
            return {
              ...e,
              hidden: true,
            }
          }
          return e
        }),
      )
    },
    [setEdges, nodes],
  )

  // Function to show nodes of a specific level in a fabric
  const showNodesOfLevelInFabric = useCallback(
    (level: string, fabricId: string) => {
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.level === level && n.data.parentFabric === fabricId) {
            return {
              ...n,
              hidden: false,
            }
          }
          return n
        }),
      )
    },
    [setNodes],
  )

  // Function to show all nodes in a fabric
  const showAllNodesInFabric = useCallback(
    (fabricId: string) => {
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.parentFabric === fabricId) {
            return {
              ...n,
              hidden: false,
              data: {
                ...n.data,
                isExpanded: true,
              },
            }
          }
          return n
        }),
      )
    },
    [setNodes],
  )

  // Function to show connections between two nodes
  const showConnectionsBetweenNodes = useCallback(
    (sourceId: string, targetLevel: string, connectionType?: string) => {
      setEdges((eds) =>
        eds.map((e) => {
          if (e.source === sourceId && (connectionType ? e.data?.type === connectionType : true)) {
            const targetNode = nodes.find((n) => n.id === e.target)
            if (targetNode && targetNode.data.level === targetLevel) {
              return {
                ...e,
                hidden: false,
              }
            }
          }
          return e
        }),
      )
    },
    [setEdges, nodes],
  )

  // Function to show all edges in a fabric
  const showAllEdgesInFabric = useCallback(
    (fabricId: string) => {
      setEdges((eds) =>
        eds.map((e) => {
          const sourceNode = nodes.find((n) => n.id === e.source)
          const targetNode = nodes.find((n) => n.id === e.target)

          // Only show edges where both source and target nodes are visible
          if (
            sourceNode &&
            targetNode &&
            !sourceNode.hidden &&
            !targetNode.hidden &&
            (sourceNode.data.parentFabric === fabricId ||
              sourceNode.id === fabricId ||
              targetNode.data.parentFabric === fabricId ||
              targetNode.id === fabricId)
          ) {
            return {
              ...e,
              hidden: false,
            }
          }
          return e
        }),
      )
    },
    [setEdges, nodes],
  )

  // Function to show leaves in a cabinet
  const showLeavesInCabinet = useCallback(
    (cabinetId: string) => {
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.level === "leaf" && n.data.parentCabinet === cabinetId) {
            return {
              ...n,
              hidden: false,
            }
          }
          return n
        }),
      )
    },
    [setNodes],
  )

  // Function to expand all nodes in a fabric
  const expandAllInFabric = useCallback(
    (fabricId: string) => {
      // First, make the fabric itself expanded
      setNodes((nds) =>
        nds.map((n) => {
          if (n.id === fabricId) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: true,
              },
              hidden: false,
            }
          }
          return n
        }),
      )

      // Then expand and show all nodes in this fabric
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.parentFabric === fabricId) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: true,
              },
              hidden: false,
            }
          }
          return n
        }),
      )

      // We need to wait for the nodes state to update before showing edges
      setTimeout(() => {
        // Show ALL edges where both source and target are visible
        setEdges((eds) =>
          eds.map((e) => {
            const sourceNode = nodes.find((n) => n.id === e.source)
            const targetNode = nodes.find((n) => n.id === e.target)

            // Check if both nodes are related to this fabric
            const isSourceInFabric =
              sourceNode && (sourceNode.id === fabricId || sourceNode.data.parentFabric === fabricId)
            const isTargetInFabric =
              targetNode && (targetNode.id === fabricId || targetNode.data.parentFabric === fabricId)

            // If both source and target are in this fabric, show the edge
            if (isSourceInFabric && isTargetInFabric) {
              return {
                ...e,
                hidden: false,
              }
            }
            return e
          }),
        )
      }, 500)
    },
    [setNodes, setEdges, nodes],
  )

  // Function to collapse all nodes in a fabric
  const collapseAllInFabric = useCallback(
    (fabricId: string) => {
      // Set all nodes in this fabric to collapsed except the fabric itself
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.parentFabric === fabricId) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: false,
              },
              hidden: true,
            }
          } else if (n.id === fabricId) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: true, // Keep the fabric expanded
              },
            }
          }
          return n
        }),
      )

      // Hide all edges in this fabric except connections to the fabric
      setEdges((eds) =>
        eds.map((e) => {
          const sourceNode = nodes.find((n) => n.id === e.source)
          const targetNode = nodes.find((n) => n.id === e.target)

          if (
            (sourceNode && sourceNode.data.parentFabric === fabricId && sourceNode.id !== fabricId) ||
            (targetNode && targetNode.data.parentFabric === fabricId && targetNode.id !== fabricId)
          ) {
            return {
              ...e,
              hidden: true,
            }
          }
          return e
        }),
      )
    },
    [setNodes, setEdges, nodes],
  )

  // Function to handle pod collapse
  const handlePodCollapse = useCallback(
    (nodeId: string) => {
      // Hide connections from this pod
      hideConnectionsFromNode(nodeId)

      // If all pods are collapsed, hide everything below
      if (areAllPodsCollapsed()) {
        // Hide all non-pod nodes
        setNodes((nds) =>
          nds.map((n) => {
            if (n.data.level !== "pod") {
              return {
                ...n,
                data: {
                  ...n.data,
                  isExpanded: false,
                },
                hidden: true,
              }
            }
            return n
          }),
        )

        // Hide all edges except pod-to-pod
        setEdges((eds) =>
          eds.map((e) => {
            const sourceNode = nodes.find((n) => n.id === e.source)
            const targetNode = nodes.find((n) => n.id === e.target)

            if (sourceNode && targetNode && (sourceNode.data.level !== "pod" || targetNode.data.level !== "pod")) {
              return {
                ...e,
                hidden: true,
              }
            }
            return e
          }),
        )
      } else if (!hasConnectionsFromOtherNodes(nodeId, "pod")) {
        // If no other pods have connections to fabrics, hide fabrics and all their children
        const fabricNodes = nodes.filter((n) => n.data.level === "fabric")

        // For each fabric, hide it and all its children
        fabricNodes.forEach((fabricNode) => {
          const fabricId = fabricNode.id

          // Hide all nodes in this fabric
          setNodes((nds) =>
            nds.map((n) => {
              if (n.id === fabricId || n.data.parentFabric === fabricId) {
                return {
                  ...n,
                  data: {
                    ...n.data,
                    isExpanded: false,
                  },
                  hidden: true,
                }
              }
              return n
            }),
          )

          // Hide all edges connected to this fabric
          setEdges((eds) =>
            eds.map((e) => {
              const sourceNode = nodes.find((n) => n.id === e.source)
              const targetNode = nodes.find((n) => n.id === e.target)

              if (
                (sourceNode && (sourceNode.id === fabricId || sourceNode.data.parentFabric === fabricId)) ||
                (targetNode && (targetNode.id === fabricId || targetNode.data.parentFabric === fabricId))
              ) {
                return {
                  ...e,
                  hidden: true,
                }
              }
              return e
            }),
          )
        })
      }
    },
    [hideConnectionsFromNode, areAllPodsCollapsed, hasConnectionsFromOtherNodes, setNodes, setEdges, nodes],
  )

  // Function to handle fabric collapse
  const handleFabricCollapse = useCallback(
    (nodeId: string) => {
      // Hide all nodes that belong to this fabric
      hideAllNodesInFabric(nodeId)

      // Hide all edges connected to nodes in this fabric
      hideAllEdgesInFabric(nodeId)
    },
    [hideAllNodesInFabric, hideAllEdgesInFabric],
  )

  // Function to handle border collapse
  const handleBorderCollapse = useCallback(
    (nodeId: string, fabricId: string) => {
      // Hide connections from this border
      hideConnectionsFromNode(nodeId)

      // If all borders in this fabric are collapsed, hide all spines and below
      if (areAllNodesOfTypeCollapsed("border", fabricId)) {
        // Hide all spines, cabinets, and leaves in this fabric
        const levelsToHide = ["spine", "cabinet", "leaf"]

        // Hide all nodes of these levels
        setNodes((nds) =>
          nds.map((n) => {
            if (levelsToHide.includes(n.data.level) && n.data.parentFabric === fabricId) {
              return {
                ...n,
                data: {
                  ...n.data,
                  isExpanded: false,
                },
                hidden: true,
              }
            }
            return n
          }),
        )

        // Hide all edges connected to these levels
        setEdges((eds) =>
          eds.map((e) => {
            const sourceNode = nodes.find((n) => n.id === e.source)
            const targetNode = nodes.find((n) => n.id === e.target)

            if (
              (sourceNode &&
                levelsToHide.includes(sourceNode.data.level) &&
                sourceNode.data.parentFabric === fabricId) ||
              (targetNode && levelsToHide.includes(targetNode.data.level) && targetNode.data.parentFabric === fabricId)
            ) {
              return {
                ...e,
                hidden: true,
              }
            }
            return e
          }),
        )
      } else if (!hasConnectionsFromOtherNodes(nodeId, "border", fabricId)) {
        // If no other borders have connections to spines, hide spines and everything below
        const levelsToHide = ["spine", "cabinet", "leaf"]
        hideNodesOfLevelsInFabric(levelsToHide, fabricId)
      }
    },
    [
      hideConnectionsFromNode,
      areAllNodesOfTypeCollapsed,
      hideNodesOfLevelsInFabric,
      hasConnectionsFromOtherNodes,
      setNodes,
      setEdges,
      nodes,
    ],
  )

  // Function to handle spine collapse
  const handleSpineCollapse = useCallback(
    (nodeId: string, fabricId: string) => {
      // Hide connections from this spine
      hideConnectionsFromNode(nodeId)

      // If all spines in this fabric are collapsed, hide all cabinets and leaves
      if (areAllNodesOfTypeCollapsed("spine", fabricId)) {
        // Hide all cabinets and leaves in this fabric
        hideNodesOfLevelsInFabric(["cabinet", "leaf"], fabricId)

        // Hide all edges below spine level
        hideEdgesBetweenLevelsInFabric(["cabinet", "leaf"], fabricId)
      } else if (!hasConnectionsFromOtherNodes(nodeId, "spine", fabricId)) {
        // If no other spines have connections to cabinets/leaves, hide them
        hideNodesOfLevelsInFabric(["cabinet", "leaf"], fabricId)
      }
    },
    [
      hideConnectionsFromNode,
      areAllNodesOfTypeCollapsed,
      hideNodesOfLevelsInFabric,
      hideEdgesBetweenLevelsInFabric,
      hasConnectionsFromOtherNodes,
    ],
  )

  // Function to handle cabinet collapse
  const handleCabinetCollapse = useCallback(
    (nodeId: string) => {
      // Hide leaves that belong to this cabinet
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.level === "leaf" && n.data.parentCabinet === nodeId) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: false,
              },
              hidden: true,
            }
          }
          return n
        }),
      )

      // Hide edges connected to leaves in this cabinet
      setEdges((eds) =>
        eds.map((e) => {
          const targetNode = nodes.find((n) => n.id === e.target)
          if (targetNode && targetNode.data.level === "leaf" && targetNode.data.parentCabinet === nodeId) {
            return {
              ...e,
              hidden: true,
            }
          }
          return e
        }),
      )
    },
    [setNodes, setEdges, nodes],
  )

  // Function to handle pod expansion
  const handlePodExpansion = useCallback(
    (nodeId: string) => {
      // Show all fabrics
      setNodes((nds) =>
        nds.map((n) => {
          if (n.data.level === "fabric") {
            return {
              ...n,
              hidden: false,
            }
          }
          return n
        }),
      )

      // Show pod-to-fabric connections
      showConnectionsBetweenNodes(nodeId, "fabric", "pod-to-fabric")
    },
    [setNodes, showConnectionsBetweenNodes],
  )

  // Function to handle fabric expansion
  const handleFabricExpansion = useCallback(
    (nodeId: string) => {
      // Show ONLY borders that belong to this fabric (not cabinets)
      showNodesOfLevelInFabric("border", nodeId)

      // Show fabric-to-border connections
      setEdges((eds) =>
        eds.map((e) => {
          const sourceNode = nodes.find((n) => n.id === e.source)
          const targetNode = nodes.find((n) => n.id === e.target)

          if (
            sourceNode &&
            targetNode &&
            sourceNode.id === nodeId &&
            targetNode.data.level === "border" &&
            targetNode.data.parentFabric === nodeId
          ) {
            return {
              ...e,
              hidden: false,
            }
          }
          return e
        }),
      )
    },
    [showNodesOfLevelInFabric, setEdges, nodes],
  )

  // Function to handle border expansion
  const handleBorderExpansion = useCallback(
    (nodeId: string, fabricId: string) => {
      // Show all spines in the same fabric
      showNodesOfLevelInFabric("spine", fabricId)

      // Show border-to-spine connections
      showConnectionsBetweenNodes(nodeId, "spine", "border-to-spine")
    },
    [showNodesOfLevelInFabric, showConnectionsBetweenNodes],
  )

  // Function to handle spine expansion
  const handleSpineExpansion = useCallback(
    (nodeId: string, fabricId: string) => {
      // Show all cabinets in the same fabric
      showNodesOfLevelInFabric("cabinet", fabricId)

      // Show all leaves in the same fabric
      showNodesOfLevelInFabric("leaf", fabricId)

      // Show spine-to-leaf connections from this spine
      showConnectionsBetweenNodes(nodeId, "leaf", "spine-to-leaf")
    },
    [showNodesOfLevelInFabric, showConnectionsBetweenNodes],
  )

  // Function to handle cabinet expansion
  const handleCabinetExpansion = useCallback(
    (nodeId: string) => {
      // Show leaves that belong to this cabinet
      showLeavesInCabinet(nodeId)

      // Show connections to leaves in this cabinet
      setEdges((eds) =>
        eds.map((e) => {
          const targetNode = nodes.find((n) => n.id === e.target)
          if (targetNode && targetNode.data.level === "leaf" && targetNode.data.parentCabinet === nodeId) {
            return {
              ...e,
              hidden: false,
            }
          }
          return e
        }),
      )
    },
    [showLeavesInCabinet, setEdges, nodes],
  )

  // Function to expand a node and show only its immediate children
  const expandNode = useCallback(
    (nodeId: string, nodeType: string, isCurrentlyExpanded: boolean) => {
      // Get the node and its fabric ID
      const currentNode = nodes.find((n) => n.id === nodeId)
      if (!currentNode) return

      const fabricId = currentNode.data.parentFabric

      if (isCurrentlyExpanded) {
        // COLLAPSING: Handle based on node type
        switch (nodeType) {
          case "pod":
            handlePodCollapse(nodeId)
            break
          case "fabric":
            handleFabricCollapse(nodeId)
            break
          case "border":
            handleBorderCollapse(nodeId, fabricId)
            break
          case "spine":
            handleSpineCollapse(nodeId, fabricId)
            break
          case "cabinet":
            handleCabinetCollapse(nodeId)
            break
        }
      } else {
        // EXPANDING: Show only the immediate next level
        switch (nodeType) {
          case "pod":
            handlePodExpansion(nodeId)
            break
          case "fabric":
            handleFabricExpansion(nodeId)
            break
          case "border":
            handleBorderExpansion(nodeId, fabricId)
            break
          case "spine":
            handleSpineExpansion(nodeId, fabricId)
            break
          case "cabinet":
            handleCabinetExpansion(nodeId)
            break
        }
      }
    },
    [
      nodes,
      handlePodCollapse,
      handleFabricCollapse,
      handleBorderCollapse,
      handleSpineCollapse,
      handleCabinetCollapse,
      handlePodExpansion,
      handleFabricExpansion,
      handleBorderExpansion,
      handleSpineExpansion,
      handleCabinetExpansion,
    ],
  )

  // Handle node click to expand/collapse nodes
  const onNodeClick = useCallback(
    (event: React.MouseEvent, node: Node) => {
      const isExpanded = node.data.isExpanded || false
      const nodeType = node.data.level

      // Toggle expansion state
      setNodes((nds) =>
        nds.map((n) => {
          if (n.id === node.id) {
            return {
              ...n,
              data: {
                ...n.data,
                isExpanded: !isExpanded,
              },
            }
          }
          return n
        }),
      )

      // Handle expansion/collapse based on node type
      expandNode(node.id, nodeType, isExpanded)
    },
    [setNodes, expandNode],
  )

  // Function to expand or collapse all nodes
  const expandCollapseAll = useCallback(
    (expand: boolean) => {
      if (expand) {
        // Expand all: show all nodes and connections
        setNodes((nds) =>
          nds.map((n) => ({
            ...n,
            data: {
              ...n.data,
              isExpanded: true,
              onExpandAll: n.data.onExpandAll,
              onCollapseAll: n.data.onCollapseAll,
              onShowDetails: n.data.onShowDetails,
            },
            hidden: false,
          })),
        )

        setEdges((eds) =>
          eds.map((e) => ({
            ...e,
            hidden: false,
          })),
        )
      } else {
        // Collapse all: show only pods, hide everything else
        setNodes((nds) =>
          nds.map((n) => ({
            ...n,
            data: {
              ...n.data,
              isExpanded: false,
              onExpandAll: n.data.onExpandAll,
              onCollapseAll: n.data.onCollapseAll,
              onShowDetails: n.data.onShowDetails,
            },
            hidden: n.data.level !== "pod",
          })),
        )

        setEdges((eds) =>
          eds.map((e) => ({
            ...e,
            hidden: true,
          })),
        )
      }
    },
    [setNodes, setEdges],
  )

  // Function to reset the topology layout
  const resetLayout = useCallback(() => {
    setNodes((nds) =>
      nds.map((n) => {
        const initialPos = initialNodePositions[n.id]
        if (initialPos) {
          return {
            ...n,
            position: initialPos,
          }
        }
        return n
      }),
    )

    // Fit view after resetting
    setTimeout(() => {
      reactFlowInstance.fitView({ padding: 0.2 })
    }, 50)
  }, [setNodes, initialNodePositions, reactFlowInstance])

  // Apply filters
  useEffect(() => {
    setEdges((eds) =>
      eds.map((e) => {
        const shouldHideByHealth = healthFilter !== "all" && e.data?.health !== healthFilter

        const shouldHideBySearch =
          searchTerm !== "" &&
          !e.source.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !e.target.toLowerCase().includes(searchTerm.toLowerCase())

        return {
          ...e,
          hidden: e.hidden || shouldHideByHealth || shouldHideBySearch,
        }
      }),
    )

    setNodes((nds) =>
      nds.map((n) => {
        const shouldHideBySearch =
          searchTerm !== "" &&
          !n.id.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !n.data.label.toLowerCase().includes(searchTerm.toLowerCase())

        return {
          ...n,
          hidden: n.hidden || shouldHideBySearch,
        }
      }),
    )
  }, [healthFilter, searchTerm, setEdges, setNodes])

  // Close edge details panel
  const closeDetailsPanel = useCallback(() => {
    setSelectedEdge(null)
  }, [])

  // Close device details panel
  const closeDevicePanel = useCallback(() => {
    setSelectedDevice(null)
  }, [])

  // Update edge data periodically (simulating live updates)
  useEffect(() => {
    const interval = setInterval(() => {
      setEdges((eds) =>
        eds.map((edge) => {
          if (!edge.data) return edge

          // Randomly update some metrics
          const utilization = Math.min(100, edge.data.utilization + (Math.random() > 0.5 ? 1 : -1) * Math.random() * 5)

          const packetErrorRate = Math.max(
            0,
            edge.data.packetErrorRate + (Math.random() > 0.7 ? 0.01 : -0.01) * Math.random(),
          )

          const latency = Math.max(0.1, edge.data.latency + (Math.random() > 0.6 ? 0.1 : -0.1) * Math.random())

          // Update health status based on metrics
          let health = "up"
          if (utilization > 90 || packetErrorRate > 0.1 || latency > 5) {
            health = "degraded"
          }
          if (utilization > 98 || packetErrorRate > 0.5 || latency > 10) {
            health = "down"
          }

          return {
            ...edge,
            data: {
              ...edge.data,
              utilization,
              packetErrorRate,
              latency,
              health,
              lastUpdated: new Date().toISOString(),
            },
          }
        }),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [setEdges])

  return (
    <div className="w-full h-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onEdgeClick={onEdgeClick}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        fitView
        minZoom={0.2}
        maxZoom={2}
        attributionPosition="bottom-right"
      >
        <Background />
        <Controls />
        <MiniMap nodeStrokeWidth={3} zoomable pannable className="bg-white/80 rounded-md shadow-md" />
        <Panel position="top-left" className="bg-white/90 p-3 rounded-md shadow-md">
          <TopologyControls
            healthFilter={healthFilter}
            setHealthFilter={setHealthFilter}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            onExpandAll={() => expandCollapseAll(true)}
            onCollapseAll={() => expandCollapseAll(false)}
            onResetLayout={resetLayout}
          />
        </Panel>
      </ReactFlow>
      {selectedEdge && <EdgeDetailsPanel edge={selectedEdge} onClose={closeDetailsPanel} />}
      {selectedDevice && (
        <DeviceDetailsPanel deviceId={selectedDevice.id} deviceType={selectedDevice.type} onClose={closeDevicePanel} />
      )}
    </div>
  )
}

export default function NetworkTopologyVisualizer() {
  return (
    <ReactFlowProvider>
      <NetworkTopologyVisualizerContent />
    </ReactFlowProvider>
  )
}
