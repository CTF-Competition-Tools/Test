"use client"

import type React from "react"

import { memo } from "react"
import { Handle, Position, type NodeProps } from "reactflow"
import { Cpu, Info } from "lucide-react"

export const LeafNode = memo(({ data, isConnectable, id }: NodeProps) => {
  const handleInfoClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (data.onShowDetails) {
      data.onShowDetails(id, "leaf")
    }
  }

  return (
    <div className="px-3 py-1 shadow-md rounded-md bg-white border-2 border-gray-200 min-w-[120px]">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="rounded-full w-6 h-6 flex items-center justify-center bg-red-100">
            <Cpu className="w-4 h-4 text-red-500" />
          </div>
          <div className="ml-2">
            <div className="text-sm font-bold">{data.label}</div>
            <div className="text-xs text-gray-500">{data.ports} Ports</div>
          </div>
        </div>
        <button
          onClick={handleInfoClick}
          className="p-1 rounded-full hover:bg-red-100 text-red-500"
          title="Show Details"
        >
          <Info className="w-4 h-4" />
        </button>
      </div>

      <Handle type="target" position={Position.Top} isConnectable={isConnectable} className="w-2 h-2 bg-red-500" />
    </div>
  )
})

LeafNode.displayName = "LeafNode"
