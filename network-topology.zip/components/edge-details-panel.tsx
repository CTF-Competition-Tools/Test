"use client"

import type { Edge } from "reactflow"
import { X } from "lucide-react"

interface EdgeDetailsPanelProps {
  edge: Edge
  onClose: () => void
}

export default function EdgeDetailsPanel({ edge, onClose }: EdgeDetailsPanelProps) {
  if (!edge.data) {
    return null
  }

  const {
    sourceDevice,
    targetDevice,
    sourceInterface,
    targetInterface,
    type,
    speed,
    capacity,
    utilization,
    bandwidth,
    packetErrorRate,
    latency,
    health,
    lastUpdated,
  } = edge.data

  // Format the timestamp
  const formattedTimestamp = new Date(lastUpdated).toLocaleString()

  // Determine status badge color
  let statusColor = "bg-green-100 text-green-800"
  let statusText = "Up"

  if (health === "degraded") {
    statusColor = "bg-yellow-100 text-yellow-800"
    statusText = "Degraded"
  } else if (health === "down") {
    statusColor = "bg-red-100 text-red-800"
    statusText = "Down"
  }

  return (
    <div className="absolute top-4 right-4 w-80 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
      <div className="flex justify-between items-center p-4 border-b border-gray-200 bg-gray-50">
        <h3 className="font-medium">Connection Details</h3>
        <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        <div>
          <div className="text-sm font-medium text-gray-500">Source → Target</div>
          <div className="font-medium">
            {sourceDevice} → {targetDevice}
          </div>
        </div>

        <div>
          <div className="text-sm font-medium text-gray-500">Device Interfaces</div>
          <div>
            {sourceInterface} → {targetInterface}
          </div>
        </div>

        <div>
          <div className="text-sm font-medium text-gray-500">Link Type</div>
          <div className="capitalize">{type.replace(/-/g, " ")}</div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm font-medium text-gray-500">Speed</div>
            <div>{speed}</div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-500">Current Bandwidth</div>
            <div>{bandwidth} Gbps</div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-500">Utilization</div>
            <div>{utilization.toFixed(1)}%</div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-500">Packet Error Rate</div>
            <div>{packetErrorRate.toFixed(3)}%</div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-500">Latency</div>
            <div>{latency.toFixed(1)} ms</div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-500">Health Status</div>
            <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColor}`}>
              {statusText}
            </div>
          </div>
        </div>

        <div>
          <div className="text-sm font-medium text-gray-500">Last Updated</div>
          <div className="text-sm">{formattedTimestamp}</div>
        </div>
      </div>
    </div>
  )
}
