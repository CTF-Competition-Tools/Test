"use client"

import { useState, useEffect } from "react"
import { X, Server, Network, Router, Cpu, Box, RefreshCw } from "lucide-react"

// Mock function to fetch device details
const fetchDeviceDetails = async (deviceId: string, deviceType: string) => {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Generate mock data based on device type
  const commonData = {
    id: deviceId,
    status: Math.random() > 0.8 ? "degraded" : Math.random() > 0.9 ? "down" : "up",
    installDate: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    firmwareVersion: `v${Math.floor(Math.random() * 5)}.${Math.floor(Math.random() * 10)}.${Math.floor(
      Math.random() * 20,
    )}`,
    lastUpdated: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
    serialNumber: `SN-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
    manufacturer: ["Cisco", "Juniper", "Arista", "HPE", "Dell"][Math.floor(Math.random() * 5)],
    model: `Model-${Math.floor(Math.random() * 1000)}`,
    location: `Datacenter ${Math.floor(Math.random() * 5) + 1}, Row ${String.fromCharCode(
      65 + Math.floor(Math.random() * 26),
    )}, Rack ${Math.floor(Math.random() * 50) + 1}`,
  }

  // Add type-specific data
  switch (deviceType) {
    case "pod":
      return {
        ...commonData,
        type: "Pod",
        role: "Entry Aggregation",
        throughput: `${Math.floor(Math.random() * 100)}Tbps`,
        connectedDevices: Math.floor(Math.random() * 50) + 10,
        routingProtocols: ["BGP", "OSPF", "IS-IS"],
      }
    case "fabric":
      return {
        ...commonData,
        type: "Fabric",
        borderCount: Math.floor(Math.random() * 8) + 2,
        spineCount: Math.floor(Math.random() * 12) + 4,
        cabinetCount: Math.floor(Math.random() * 20) + 5,
        totalCapacity: `${Math.floor(Math.random() * 500) + 100}Tbps`,
      }
    case "border":
      return {
        ...commonData,
        type: "Border Device",
        role: "Fabric Border Router",
        interfaces: Math.floor(Math.random() * 48) + 24,
        routingProtocols: ["BGP", "OSPF"],
        acl: Math.floor(Math.random() * 100) + 20,
        throughput: `${Math.floor(Math.random() * 10) + 5}Tbps`,
      }
    case "spine":
      return {
        ...commonData,
        type: "Spine Switch",
        interfaces: Math.floor(Math.random() * 64) + 32,
        switchingCapacity: `${Math.floor(Math.random() * 20) + 10}Tbps`,
        bufferSize: `${Math.floor(Math.random() * 100) + 50}MB`,
        macAddressTable: Math.floor(Math.random() * 100000) + 50000,
      }
    case "cabinet":
      return {
        ...commonData,
        type: "Cabinet",
        leafCount: Math.floor(Math.random() * 6) + 2,
        rackUnits: Math.floor(Math.random() * 30) + 20,
        powerCapacity: `${Math.floor(Math.random() * 10) + 5}kW`,
        coolingCapacity: `${Math.floor(Math.random() * 20) + 10}kW`,
        weight: `${Math.floor(Math.random() * 500) + 300}kg`,
      }
    case "leaf":
      return {
        ...commonData,
        type: "Leaf Switch",
        ports: Math.floor(Math.random() * 48) + 24,
        switchingCapacity: `${Math.floor(Math.random() * 5) + 1}Tbps`,
        bufferSize: `${Math.floor(Math.random() * 50) + 20}MB`,
        macAddressTable: Math.floor(Math.random() * 50000) + 10000,
        vlans: Math.floor(Math.random() * 500) + 100,
      }
    default:
      return commonData
  }
}

interface DeviceDetailsPanelProps {
  deviceId: string
  deviceType: string
  onClose: () => void
}

export default function DeviceDetailsPanel({ deviceId, deviceType, onClose }: DeviceDetailsPanelProps) {
  const [deviceData, setDeviceData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadDeviceData = async () => {
      try {
        setLoading(true)
        const data = await fetchDeviceDetails(deviceId, deviceType)
        setDeviceData(data)
        setError(null)
      } catch (err) {
        setError("Failed to load device details")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    loadDeviceData()
  }, [deviceId, deviceType])

  // Get the appropriate icon based on device type
  const getDeviceIcon = () => {
    switch (deviceType) {
      case "pod":
        return <Network className="w-5 h-5 text-indigo-500" />
      case "fabric":
        return <Server className="w-5 h-5 text-purple-500" />
      case "border":
        return <Router className="w-5 h-5 text-blue-500" />
      case "spine":
        return <Network className="w-5 h-5 text-green-500" />
      case "cabinet":
        return <Box className="w-5 h-5 text-amber-500" />
      case "leaf":
        return <Cpu className="w-5 h-5 text-red-500" />
      default:
        return <Server className="w-5 h-5 text-gray-500" />
    }
  }

  // Determine status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "up":
        return "bg-green-100 text-green-800"
      case "degraded":
        return "bg-yellow-100 text-yellow-800"
      case "down":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Format the timestamp
  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <div className="absolute top-4 left-4 w-80 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
      <div className="flex justify-between items-center p-4 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center">
          {getDeviceIcon()}
          <h3 className="font-medium ml-2">Device Details</h3>
        </div>
        <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      {loading ? (
        <div className="p-4 flex justify-center items-center">
          <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />
          <span className="ml-2">Loading device details...</span>
        </div>
      ) : error ? (
        <div className="p-4 text-red-500">{error}</div>
      ) : deviceData ? (
        <div className="p-4 space-y-4 max-h-[80vh] overflow-y-auto">
          <div>
            <div className="text-sm font-medium text-gray-500">Device ID</div>
            <div className="font-medium">{deviceData.id}</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm font-medium text-gray-500">Type</div>
              <div>{deviceData.type}</div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-500">Status</div>
              <div
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(
                  deviceData.status,
                )}`}
              >
                {deviceData.status.charAt(0).toUpperCase() + deviceData.status.slice(1)}
              </div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-500">Manufacturer</div>
              <div>{deviceData.manufacturer}</div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-500">Model</div>
              <div>{deviceData.model}</div>
            </div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-500">Location</div>
            <div>{deviceData.location}</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm font-medium text-gray-500">Serial Number</div>
              <div className="text-sm font-mono">{deviceData.serialNumber}</div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-500">Firmware</div>
              <div className="text-sm">{deviceData.firmwareVersion}</div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-500">Install Date</div>
              <div className="text-sm">{deviceData.installDate}</div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-500">Last Updated</div>
              <div className="text-sm">{formatTimestamp(deviceData.lastUpdated)}</div>
            </div>
          </div>

          {/* Device-specific details */}
          {deviceData.type === "Pod" && (
            <div className="space-y-3 pt-2 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Role</div>
                  <div>{deviceData.role}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Throughput</div>
                  <div>{deviceData.throughput}</div>
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Connected Devices</div>
                <div>{deviceData.connectedDevices}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Routing Protocols</div>
                <div>{deviceData.routingProtocols.join(", ")}</div>
              </div>
            </div>
          )}

          {deviceData.type === "Fabric" && (
            <div className="space-y-3 pt-2 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Border Devices</div>
                  <div>{deviceData.borderCount}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Spine Switches</div>
                  <div>{deviceData.spineCount}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Cabinets</div>
                  <div>{deviceData.cabinetCount}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Total Capacity</div>
                  <div>{deviceData.totalCapacity}</div>
                </div>
              </div>
            </div>
          )}

          {deviceData.type === "Border Device" && (
            <div className="space-y-3 pt-2 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Role</div>
                  <div>{deviceData.role}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Interfaces</div>
                  <div>{deviceData.interfaces}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">ACL Count</div>
                  <div>{deviceData.acl}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Throughput</div>
                  <div>{deviceData.throughput}</div>
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Routing Protocols</div>
                <div>{deviceData.routingProtocols.join(", ")}</div>
              </div>
            </div>
          )}

          {deviceData.type === "Spine Switch" && (
            <div className="space-y-3 pt-2 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Interfaces</div>
                  <div>{deviceData.interfaces}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Switching Capacity</div>
                  <div>{deviceData.switchingCapacity}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Buffer Size</div>
                  <div>{deviceData.bufferSize}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">MAC Address Table</div>
                  <div>{deviceData.macAddressTable.toLocaleString()}</div>
                </div>
              </div>
            </div>
          )}

          {deviceData.type === "Cabinet" && (
            <div className="space-y-3 pt-2 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Leaf Switches</div>
                  <div>{deviceData.leafCount}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Rack Units</div>
                  <div>{deviceData.rackUnits}U</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Power Capacity</div>
                  <div>{deviceData.powerCapacity}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Cooling Capacity</div>
                  <div>{deviceData.coolingCapacity}</div>
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Weight</div>
                <div>{deviceData.weight}</div>
              </div>
            </div>
          )}

          {deviceData.type === "Leaf Switch" && (
            <div className="space-y-3 pt-2 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-gray-500">Ports</div>
                  <div>{deviceData.ports}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Switching Capacity</div>
                  <div>{deviceData.switchingCapacity}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">Buffer Size</div>
                  <div>{deviceData.bufferSize}</div>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-500">VLANs</div>
                  <div>{deviceData.vlans}</div>
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">MAC Address Table</div>
                <div>{deviceData.macAddressTable.toLocaleString()}</div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="p-4">No data available</div>
      )}
    </div>
  )
}
