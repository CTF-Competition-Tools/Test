import { memo } from "react"
import { type EdgeProps, getBezierPath } from "reactflow"

export const StatusEdge = memo(
  ({
    id,
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    data,
    style = {},
    markerEnd,
  }: EdgeProps) => {
    const [edgePath] = getBezierPath({
      sourceX,
      sourceY,
      sourcePosition,
      targetX,
      targetY,
      targetPosition,
    })

    // Default to healthy if no data
    const health = data?.health || "up"

    // Determine color based on health status
    let strokeColor = "#22c55e" // green-500 for healthy
    if (health === "degraded") {
      strokeColor = "#eab308" // yellow-500 for degraded
    } else if (health === "down") {
      strokeColor = "#ef4444" // red-500 for down
    }

    // Determine stroke width based on bandwidth capacity
    const baseWidth = 2
    const capacityMultiplier = data?.capacity ? Math.log10(data.capacity) / 2 : 1
    const strokeWidth = baseWidth * capacityMultiplier

    // Determine opacity based on utilization
    const utilization = data?.utilization || 0
    const opacity = 0.4 + (utilization / 100) * 0.6

    return (
      <>
        <path
          id={id}
          style={{
            ...style,
            strokeWidth,
            stroke: strokeColor,
            opacity,
            transition: "stroke 0.3s, stroke-width 0.3s, opacity 0.3s",
          }}
          className="react-flow__edge-path"
          d={edgePath}
          markerEnd={markerEnd}
        />
        {data?.type === "pod-to-spine" && (
          <text>
            <textPath
              href={`#${id}`}
              style={{ fontSize: 10 }}
              startOffset="50%"
              textAnchor="middle"
              className="text-xs fill-gray-500"
            >
              {data.utilization ? `${Math.round(data.utilization)}%` : ""}
            </textPath>
          </text>
        )}
      </>
    )
  },
)

StatusEdge.displayName = "StatusEdge"
